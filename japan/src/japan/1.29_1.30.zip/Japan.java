package japan;

import japanSub.JapanSub;

public class Japan {

	public static void main(String[] args) {
		System.out.println("出力回数の数字 +「,」+ 「-1」か「0」を入力してください");
		JapanSub.main();
	}

}
